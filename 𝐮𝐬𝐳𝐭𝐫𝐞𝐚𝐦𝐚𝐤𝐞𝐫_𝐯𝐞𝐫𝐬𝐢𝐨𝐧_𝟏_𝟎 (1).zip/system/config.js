/*
*/
//========usz-treamaker========
global.prefix = [".", "!", ".", ",", "🐤", "🗿"]; 
global.publik = true
global.owner = ["6283194962608"] 
global.namabot = '𝙪𝙨𝙯-𝙩𝙧𝙚𝙖𝙢𝙖𝙠𝙚𝙧'
//======================
global.mess = { 
owner: '𝚖𝚊𝚞 𝚓𝚊𝚍𝚒 𝚖𝚎𝚖𝚋𝚎𝚛 𝚙𝚛𝚎𝚖𝚒𝚞𝚖? 𝚖𝚊𝚜𝚞𝚔 𝚌𝚑𝚊𝚗𝚗𝚎𝚕 𝚍𝚎𝚟𝚎𝚕𝚘𝚟𝚎𝚛                       https://whatsapp.com/channel/0029Vb5ZWobDZ4LfLDRx2137',
premium: '𝚜𝚘𝚔 𝚊𝚜𝚒𝚔 𝚕𝚞 𝚋𝚞𝚔𝚊𝚗 𝚖𝚎𝚖𝚋𝚎𝚛 𝚙𝚛𝚎𝚖𝚒𝚞𝚖 𝚋𝚗𝚐 𝚞𝚜𝚣𝚝𝚛𝚎𝚊𝚖𝚊𝚔𝚎𝚛',
succes: '𝚍𝚘𝚗𝚎 𝚋𝚊𝚗𝚐 𝚞𝚜𝚣'
}
//======================